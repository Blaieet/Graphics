# RayTracingEstudiants
Practica base RayTracing dels estudiants 17-18
