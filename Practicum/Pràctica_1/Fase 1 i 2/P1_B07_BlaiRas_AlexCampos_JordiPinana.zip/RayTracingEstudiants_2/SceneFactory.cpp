#include "SceneFactory.h"

SceneFactory::SceneFactory()
{

}
