#include "Hitable.h"

Hitable::Hitable()
{

}

Hitable::~Hitable()
{

}

