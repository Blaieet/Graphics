#ifndef TRANSLATE1_H
#define TRANSLATE1_H

#include "TG.h"

class Translate1 : public TG
{
public:
    vec3 traslation;
    Translate1(vec3 trasl);

};

#endif // TRANSLATE1_H
