#ifndef SCALE1_H
#define SCALE1_H

#include "TG.h"

class Scale1 : public TG
{
public:
    Scale1(vec3 s);
    vec3 scal;
};

#endif // SCALE1_H
