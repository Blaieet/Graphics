#include "Animation.h"

Animable::Animable()
{

}
Animable::~Animable()
{

}

void Animable::addAnimation(Animation *anim) {
    animFrames.push_back(anim);
}

void Animable::update(int nframe) {

    if(animFrames.size()==0){
        qDebug()<<"Object: has no animations yet!";
        return;
    }

    bool trobat = false;
    int i;
    for (i = 0; i < animFrames.size(); i++) {
        if (nframe < animFrames[i]->frameFinal && nframe > animFrames[i]->frameIni) {
            aplicaTG(animFrames[i]->transf);
        }
    }

}
