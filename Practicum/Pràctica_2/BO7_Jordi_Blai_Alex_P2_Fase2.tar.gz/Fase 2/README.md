# B07

GiV - P1 Fase 3
----------  

## Abstract

En esta segunda entrega de la practica dos hemos creado un videclip que simula una persecucion. Concretamente, bigHero y littleHero huyen de un balón descontrolado. Además, deben esquivar una nave espacial y una valla de madera.

Podemos observar también un sol y unos árboles con el efecto del viento. 

# Additional Information
^^^^^^^^^^^^^^^^^^^^^^

* El vídeo contiene todas las animaciones desarrolladas: Rotate, Rotate pero sobre ti mismo, Translate y Scale. 


* Para observar los distintos shaders, simplemente escoge la opción que desees en la ventana de la aplicación del programa. Hay Toon Shader, Phong Shader y Goraud Shader. El vídeo está renderizado con PhongShader.
